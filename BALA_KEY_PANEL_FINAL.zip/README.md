# BALA Scanner — pacote completo

Inclui scanner (página inicial), modo grátis e tutorial, painel do proprietário em `/painel/`, funções Netlify para login/gestão/validação de keys e configuração `netlify.toml`.

## Importante antes de publicar

**IMPORTANTE: arrastar apenas o ZIP ou arquivos para “Arquivos descartados/Netlify Drop” NÃO publica as funções serverless. Por isso o painel pode mostrar “Erro na API” mesmo que a tela abra. Publique pelo GitHub conectado ao Netlify ou pelo Netlify CLI.** Para que login e keys funcionem, publique este projeto como um site Netlify com funções: conecte a pasta/repositório pelo GitHub, ou use Netlify CLI (`netlify deploy`). O arquivo `netlify.toml` já aponta `scanner/` como pasta publicada e `netlify/functions` como funções.

## Variáveis de ambiente Netlify

Em **Site configuration → Environment variables**, crie:

- `BALA_OWNER_USER` = `scanbala2026`
- `BALA_OWNER_PASSWORD` = `BALA00SCAN` (conforme solicitado; troque por uma senha forte antes de deixar o site público)
- `BALA_SESSION_SECRET` = uma sequência aleatória longa, com pelo menos 32 caracteres

Depois salve e faça um novo deploy. Não coloque a senha nem o segredo no HTML.

## Como acessar

- Scanner: `/`
- Painel do proprietário: `/painel/`

## Sistema de keys

O painel oferece nomes personalizados e durações permanente, 30, 7, 3 ou 1 dia. Para keys com duração limitada, o prazo começa na primeira ativação e continua correndo em tempo real mesmo se a pessoa fechar o site. Inclui vínculo ao identificador local do navegador, pausar/retomar, estender e excluir. O vínculo local dificulta compartilhamento casual, mas não é uma identificação inviolável de hardware.

## Limites honestos do scanner

A análise é heurística: aceita texto e tenta extrair conteúdo de texto de ZIPs, e calcula SHA-256 do arquivo original. Bug Report e Sysdiagnose podem conter formatos binários, arquivos grandes, dados incompletos ou conteúdo que não pode ser interpretado por um navegador. Indicadores como VPN, debug ou ESP não provam trapaça. Nenhum scanner baseado só nesses relatórios pode garantir 100% de detecção ou zero falsos positivos; revise os resultados manualmente.

## Teste após publicar

1. Abra `/` e teste o modo grátis e o envio de arquivo.
2. Abra `/.netlify/functions/owner-login` (uma resposta `Method not allowed` num acesso GET é normal; o login usa POST).
3. Entre em `/painel/`, crie uma key de teste e valide no scanner.
4. Teste pausa, extensão e exclusão antes de usar com membros reais.

Este pacote contém o código do projeto, mas a publicação e o funcionamento em produção dependem de configurar as variáveis e implantar as funções no Netlify.


O painel do dono atualiza a lista automaticamente a cada 5 segundos enquanto estiver aberto. O botão Atualizar continua disponível.
