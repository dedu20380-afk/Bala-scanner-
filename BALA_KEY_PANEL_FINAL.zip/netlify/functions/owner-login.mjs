import crypto from "node:crypto";
export default async (req)=>{
 if(req.method==="OPTIONS")return new Response("",{status:204,"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"Content-Type, Authorization","Access-Control-Allow-Methods":"POST,OPTIONS"});
 if(req.method!=="POST")return new Response("Method not allowed",{status:405});
 const {username,password}=await req.json().catch(()=>({}));
 const user=process.env.BALA_OWNER_USER||"scanbala2026",pass=process.env.BALA_OWNER_PASSWORD||"BALA00SCAN",secret=process.env.BALA_SESSION_SECRET||"BALA-DEFAULT-SESSION-SECRET-CHANGE-IN-NETLIFY-2026";
 if(username!==user||password!==pass)return Response.json({message:"Usuário ou senha incorretos."},{status:401});
 const payload=Buffer.from(JSON.stringify({sub:user,exp:Date.now()+8*60*60*1000})).toString("base64url");
 const sig=crypto.createHmac("sha256",secret).update(payload).digest("base64url");
 return Response.json({token:payload+"."+sig});
};